:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# To Do List App

An app that serves as a basic to do list. Items are stored in a custom field created using requirements when the app is installed.

### App Has basic features:

* Create New Tasks
* Coming - Create context for tasks (like categories. Tasks will be sorted differently )
* Coming - Send task to agent.

Please submit bug reports to this app's github issues page. Pull requests are welcome.

### Screenshot(s):
![](http://cl.ly/ZoZ9/Screen%20Shot%202015-02-17%20at%2011.11.55%20AM.png)
